int main()
{
	int var;
	int *ptr;
}