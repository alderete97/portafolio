int main()
{
int a,b,c,i,o,A[ 2 ];
float h[];
if (a<b)
{
	printf(String);
	scanf(String,&o);
	switch (o){
		case 1:
			c=a+b;
		break;
		case 2:
			c=a-b;
		break;
		case 3:
			c=a*b;
		break;
		default:
			c=a/b;
	}
}
else{
	do
	{
		a--;
		c=b*3;
	} while ((a>=b)||(b<=c));
}
while(c==b){
	for ( i = 0; i != 30 && i !=0; ++i)
	{
		i+=a;
		b-=a;
	}
	c/=a+i;
}
printf(String,c);
return 0;
}